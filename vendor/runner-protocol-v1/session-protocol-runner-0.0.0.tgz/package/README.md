# Runner protocol

`@session/protocol-runner` owns the experimental `runner.protocol/v1` wire
contract. It has no runner, harness, storage, channel, or framework dependency.

The package provides:

- size-bounded JSON encode/decode with qualified security-boundary identifiers;
- one frozen experimental-v1 manifest for frames, events, commands, command
  scope/capabilities, errors, and limits;
- conservative hello/version/capability negotiation that cannot raise support
  fidelity or guess a limit intersection;
- canonical hello proof input;
- independent control, event, and bulk lanes;
- sequence duplicate/gap detection;
- typed semantic runner events and closed flow-control/NACK payloads;
- typed, bounded, lease-bound heartbeat and reconciliation frames;
- a committed implementation-neutral fixture corpus plus reusable codec
  conformance runner; and
- content-locality denial for raw command fields and restricted event bodies.

Unknown additive envelope fields survive decode. Registered commands use the
control lane, their registry-owned capability, exact qualified scope, and a
versioned semantic body discriminator. Security-sensitive event, flow-control,
NACK, heartbeat, reconciliation, and revocation payloads are closed. Unknown
schemas, unsupported versions, unknown commands, raw restricted values, invalid
expiry, oversize frames, wrong identifier namespaces, capability substitution,
scope smuggling, classification downgrade, unbounded recovery summaries, stale
cursor shapes, and content-bearing outcome descriptors fail closed with stable
protocol errors.

Run the reference suite with:

```sh
npm run runner:conformance
```

The committed corpus is
[`fixtures/runner-protocol-v1.json`](fixtures/runner-protocol-v1.json). It
contains only generated values. Conformance output reports fixture IDs and
stable reason codes, never encoded frames.

This is an internal Phase 3 interoperability contract, not a stable public API.
Gate 5 owns the public compatibility decision. Before then, breaking changes
require an explicit fixture migration rather than a silent validator change.
