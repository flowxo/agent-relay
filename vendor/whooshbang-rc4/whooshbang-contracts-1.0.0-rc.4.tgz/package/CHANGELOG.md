# Changelog

All notable contract changes are recorded here.

## 1.0.0-rc.4

- Replace the unused pre-launch product identity with WhooshBang across the
  package name, OpenAPI and schema identities, Problem Details origin,
  diagnostic header, event envelope, project and machine credential markers,
  generated types, validators, fixtures, and consumer examples.
- Rename the public package to `@whooshbang/contracts`; the prior candidate
  was never published and has no compatibility or migration requirement.

## 1.0.0-rc.3

- Add the approved N1-03 API credential lifecycle contract: account-owned
  project/environment administration paths, exact high-entropy bearer syntax,
  one-time create/rotate reveal, metadata-only listing, a zero-to-24-hour
  rotation overlap, terminal repeat-safe revocation, and indistinguishable
  invalid/revoked authentication.
- Keep published credential examples unmistakably synthetic with low-entropy
  sentinel values so repository secret scanning remains actionable.
- Require a distinct newly active replacement, coherent lifecycle timestamps,
  and an explicit old-credential revocation deadline in rotation responses;
  extend deployable-artifact scanning to WhooshBang bearer formats.
- Reissue the contract, SDK, mock, fixtures, and generated artifacts under a
  new immutable candidate identity; `1.0.0-rc.2` remains unchanged.

## 1.0.0-rc.2

- Add the N1-02 human-administration contract to the reviewed release-candidate
  line: current account projection, project create/list/read, atomic
  `test`/`live` environment and default-notifier bootstrap, account-scoped
  idempotency, slug conflict, and non-enumerating cross-account behavior.
- Reissue the manifest, schemas, fixtures, OpenAPI bundle, generated types, and
  validators under a new immutable candidate identity; `1.0.0-rc.1` remains
  unchanged.

## 1.0.0-rc.1

- Promote the exact reviewed Wave 0/C0 contract from `1.0.0-draft.1` without a
  public semantic change.
- Reissue every manifest, schema, fixture identity, OpenAPI document, generated
  output, and package-consumer assertion at the release-candidate version after
  the compatibility and adversarial security gates passed.
- Keep the candidate repository-local and unpublished so downstream consumers
  can pin and verify the exact artifact before any independent product release.

## 1.0.0-draft.1

- Establish the versioned contract workspace, ownership manifest, and package
  boundary.
- Add the canonical WhooshBang OpenAPI 3.1.1 contract for subscription-link
  creation, inspection, and cancellation and message creation, inspection, and
  cancellation.
- Add strict JSON Schema 2020-12 request, resource, delivery-attempt, binding,
  Problem Details, fixture-index, and semantic-scenario models.
- Add deterministic generated TypeScript, runtime validators, a bundled OpenAPI
  document, and golden fixtures covering success, failure, idempotency, state,
  cancellation, and tenant/environment isolation.
- Record seven-day idempotency, authenticated scope, safe error, and
  ambiguous-provider `outcome_unknown` semantics without adding production
  service, SDK, interaction, webhook, or executable mock behavior.
- Add the C0-03 tagged confirm, single-select, and input interaction request,
  lifecycle summary, and authenticated answer-event contracts with bounded
  prompts/options/input, opaque callback tokens, strict expiry ordering, and
  deterministic duplicate/stale/expired/mismatched fixtures.
- Add project-administered machine-client and digest-only credential
  registration/revocation contracts, exact locally generated
  `wb_mc1.<credential-id>.<secret>` syntax, Web Crypto generation and
  constant-time digest verification helpers, and safe metadata responses that
  contain neither a readable secret nor digest.
- Add bounded long polling, at-least-seven-day event retention, per-event
  idempotent acknowledgement, contiguous committed cursors, crash replay,
  fail-closed foreign/uncommitted cursors, and schema-valid poison-event
  quarantine.
- Add provider-neutral capability declarations and an additive unique-provider
  collection with Telegram acceptance evidence and explicit lack of
  delivered/read evidence.
- Add the strict `whooshbang.event.v1` envelope, nine initial per-event
  schemas, generated types/validators, and safe synthetic event fixtures.
- Add Standard Webhooks-compatible raw-byte HMAC-SHA256 verification using
  Worker- and Node-compatible Web Crypto, bounded current/previous key
  rotation, strict replay/header parsing, and 28 deterministic valid and
  adversarial vectors.
- Add an independently implemented Python standard-library verifier over the
  same byte vectors and include it in the immutable package boundary.
- Add a caller-owned atomic deduplication consumer example with expected
  project/event checks and seven-day retention, plus deterministic at-least-
  once delivery classification for 2xx, redirects, retryable outcomes, safe
  Retry-After, eight attempts, and a 24-hour window.
- Keep machine message create/read authorization narrowly bound to the
  authenticated client destination and owned message IDs; cancellation,
  administration, Relay continuation/resume, multi-select/ordered sets,
  endpoint registration/delivery queues, WebSockets, SDK networking, and
  executable mock behavior remain outside this change.
