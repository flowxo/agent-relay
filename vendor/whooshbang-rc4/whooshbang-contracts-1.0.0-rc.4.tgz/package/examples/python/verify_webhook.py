#!/usr/bin/env python3
"""Verify WhooshBang Standard Webhooks fixtures with the stdlib only."""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import re
import sys
from pathlib import Path
from typing import Any

DEFAULT_TOLERANCE_SECONDS = 300
MAX_SIGNATURES = 2
MAX_SECRETS = 2

EVENT_IDENTIFIER = re.compile(r"^evt_[A-Za-z0-9_-]+$", re.ASCII)
CANONICAL_TIMESTAMP = re.compile(r"^(?:0|[1-9][0-9]{0,14})$", re.ASCII)
CANONICAL_ATTEMPT = re.compile(r"^[1-8]$", re.ASCII)
SIGNATURE_TOKEN = re.compile(
    r"^([A-Za-z0-9]+),([A-Za-z0-9+/]+={0,2})$", re.ASCII
)
CANONICAL_BASE64 = re.compile(
    r"^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$",
    re.ASCII,
)


def rejected(reason: str) -> dict[str, Any]:
    """Return a deliberately redacted verification failure."""

    return {"verified": False, "reason": reason}


def single_header(
    headers: Any, wanted_name: str
) -> tuple[str | None, str | None]:
    if not isinstance(headers, list):
        return None, "malformed_header"

    values: list[str] = []
    for entry in headers:
        if (
            not isinstance(entry, (list, tuple))
            or len(entry) != 2
            or not isinstance(entry[0], str)
            or not isinstance(entry[1], str)
        ):
            return None, "malformed_header"
        if entry[0].lower() == wanted_name:
            values.append(entry[1])

    if not values:
        return None, "missing_header"
    if len(values) != 1:
        return None, "duplicate_header"
    return values[0], None


def decode_canonical_base64(value: str) -> bytes | None:
    if CANONICAL_BASE64.fullmatch(value) is None:
        return None
    try:
        decoded = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error):
        return None
    if base64.b64encode(decoded).decode("ascii") != value:
        return None
    return decoded


def parse_secret(value: str) -> bytes | None:
    if not value.startswith("whsec_"):
        return None
    decoded = decode_canonical_base64(value[len("whsec_") :])
    if decoded is None or not 24 <= len(decoded) <= 64:
        return None
    return decoded


def parse_signatures(value: str) -> tuple[list[bytes] | None, str | None]:
    if (
        not value
        or value.startswith(" ")
        or value.endswith(" ")
        or "  " in value
    ):
        return None, "malformed_signature"

    tokens = value.split(" ")
    if len(tokens) > MAX_SIGNATURES:
        return None, "too_many_signatures"

    seen: set[str] = set()
    signatures: list[bytes] = []
    for token in tokens:
        match = SIGNATURE_TOKEN.fullmatch(token)
        if match is None:
            return None, "malformed_signature"
        version, encoded = match.groups()
        if version != "v1":
            return None, "unsupported_signature_version"
        if token in seen:
            return None, "duplicate_signature"
        seen.add(token)
        decoded = decode_canonical_base64(encoded)
        if decoded is None or len(decoded) != 32:
            return None, "malformed_signature"
        signatures.append(decoded)
    return signatures, None


def is_plain_integer(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def verify_webhook(
    *,
    raw_body: Any,
    headers: Any,
    secrets: Any,
    now_seconds: Any,
    tolerance_seconds: Any = DEFAULT_TOLERANCE_SECONDS,
) -> dict[str, Any]:
    """Verify one attempt without parsing or re-serializing its JSON body."""

    if not isinstance(raw_body, bytes):
        return rejected("invalid_body")

    event_id, error = single_header(headers, "webhook-id")
    if error is not None:
        return rejected(error)
    if (
        event_id is None
        or not 8 <= len(event_id) <= 128
        or EVENT_IDENTIFIER.fullmatch(event_id) is None
    ):
        return rejected("malformed_webhook_id")

    timestamp_text, error = single_header(headers, "webhook-timestamp")
    if error is not None:
        return rejected(error)
    if (
        timestamp_text is None
        or CANONICAL_TIMESTAMP.fullmatch(timestamp_text) is None
    ):
        return rejected("malformed_timestamp")
    timestamp = int(timestamp_text)

    signature_text, error = single_header(headers, "webhook-signature")
    if error is not None:
        return rejected(error)
    if signature_text is None:
        return rejected("malformed_signature")
    signatures, error = parse_signatures(signature_text)
    if error is not None:
        return rejected(error)
    if signatures is None:
        return rejected("malformed_signature")

    attempt_text, error = single_header(headers, "webhook-attempt")
    if error is not None:
        return rejected(error)
    if (
        attempt_text is None
        or CANONICAL_ATTEMPT.fullmatch(attempt_text) is None
    ):
        return rejected("malformed_attempt")
    attempt = int(attempt_text)

    if (
        not is_plain_integer(tolerance_seconds)
        or not 1 <= tolerance_seconds <= DEFAULT_TOLERANCE_SECONDS
    ):
        return rejected("invalid_tolerance")
    if not is_plain_integer(now_seconds) or now_seconds < 0:
        return rejected("invalid_clock")
    if abs(now_seconds - timestamp) > tolerance_seconds:
        return rejected("timestamp_outside_tolerance")

    if not isinstance(secrets, list) or not all(
        isinstance(secret, str) for secret in secrets
    ):
        return rejected("invalid_secret")
    if len(secrets) > MAX_SECRETS:
        return rejected("too_many_secrets")
    if not secrets:
        return rejected("invalid_secret")
    if len(set(secrets)) != len(secrets):
        return rejected("duplicate_secret")
    decoded_secrets = [parse_secret(secret) for secret in secrets]
    if any(secret is None for secret in decoded_secrets):
        return rejected("invalid_secret")

    signed_bytes = (
        event_id.encode("ascii")
        + b"."
        + timestamp_text.encode("ascii")
        + b"."
        + raw_body
    )
    matched = False
    for possible_secret in decoded_secrets:
        if possible_secret is None:
            continue
        digest = hmac.new(
            possible_secret, signed_bytes, hashlib.sha256
        ).digest()
        for signature in signatures:
            matched = hmac.compare_digest(digest, signature) or matched

    if not matched:
        return rejected("signature_mismatch")
    return {
        "verified": True,
        "event_id": event_id,
        "timestamp": timestamp,
        "attempt": attempt,
    }


def run_vectors(vector_path: Path) -> dict[str, Any]:
    vector_set = json.loads(vector_path.read_text(encoding="utf-8"))
    keys = vector_set["synthetic_verification_keys"]
    bodies = vector_set["raw_bodies"]
    cases = vector_set["cases"]

    for vector in cases:
        result = verify_webhook(
            raw_body=bodies[vector["raw_body"]].encode("utf-8"),
            headers=[
                (header["name"], header["value"])
                for header in vector["headers"]
            ],
            secrets=[keys[name] for name in vector["trusted_keys"]],
            now_seconds=vector["now_seconds"],
            tolerance_seconds=vector["tolerance_seconds"],
        )
        if result != vector["expected"]:
            return {
                "status": "fail",
                "code": "WEBHOOK_VECTOR_MISMATCH",
                "case_id": vector["id"],
            }

    return {
        "status": "pass",
        "code": "WEBHOOK_VECTORS_OK",
        "cases": len(cases),
    }


def main() -> int:
    if len(sys.argv) != 2:
        sys.stderr.write(
            json.dumps(
                {
                    "status": "fail",
                    "code": "WEBHOOK_VECTOR_PATH_REQUIRED",
                }
            )
            + "\n"
        )
        return 2

    try:
        summary = run_vectors(Path(sys.argv[1]))
    except Exception:
        summary = {
            "status": "fail",
            "code": "WEBHOOK_VECTOR_RUN_FAILED",
        }

    stream = sys.stdout if summary["status"] == "pass" else sys.stderr
    stream.write(json.dumps(summary, sort_keys=True) + "\n")
    return 0 if summary["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
