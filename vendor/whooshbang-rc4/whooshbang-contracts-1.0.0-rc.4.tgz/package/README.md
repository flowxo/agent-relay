# WhooshBang contract workspace

`@whooshbang/contracts` is the runtime-neutral artifact boundary for
public contracts owned by WhooshBang. This package does not publish
itself and does not depend on sibling repositories or Cloudflare runtime types.

## Source ownership

- `contract-manifest.json`, `openapi/`, `schemas/`, `fixtures/`, and
  `examples/` are canonical, human-edited inputs.
- `src/generated/` is deterministic output. Never edit it by hand; run
  `npm run contracts:generate` from the repository root.
- `dist/` and `artifacts/` are local build outputs and are not committed.
- Other products retain ownership of their own schemas. Consumer artifacts are
  pinned and exchanged as tarballs rather than accessed through sibling paths.

The manifest indexes the C0-02 core REST contract, its approved N1-02
account/project administration and N1-03 credential-lifecycle amendments, the
C0-03 interaction, machine-client, machine-event, and provider-capability
contracts, and the C0-04 signed customer-event and delivery contracts. The
canonical API is `openapi/whooshbang-v1.yaml`; its committed distribution
bundle, generated TypeScript, validators, and fixture index are checked for
drift on every contract check.

The contract intentionally stops at serialized behavior. The JavaScript SDK and
executable Hono mock provide deterministic C0-05 consumer behavior, while no
production authentication, persistence, queue, Telegram, endpoint registration,
or provider behavior lives in this package. Its bounded runtime-neutral helpers
cover local machine credential material, raw-byte webhook verification,
caller-owned idempotent consumption, and delivery-response classification. They
perform no networking or persistence.

## N1-03 credential boundary

- Human credential administration is scoped by the verified Clerk account and
  explicit account-owned project/environment path targets.
- Project bearer syntax is
  `wb_pc1.pcred_<16-byte-base64url>.<32-byte-base64url-secret>`. Creation and
  rotation reveal the complete bearer exactly once and cannot be replayed.
- Safe metadata exposes a non-secret prefix, label, scopes, opaque
  WhooshBang creator ID, creation/last-used time, and lifecycle state.
- Rotation preserves label and scopes, with an explicit overlap bounded at 24
  hours. Revocation is terminal and repeat-safe.
- The initial onboarding scope set uses `subscriptions:read` as the minimal
  resource-read scope alongside `messages:write`, `messages:read`, and
  `subscriptions:write`.

## C0-03 boundaries

- Message creation accepts an optional tagged `confirm`, single `select`, or
  `input` interaction. Expiry and first-terminal-answer behavior remain
  server-authoritative.
- Provider callback and cursor tokens are opaque references. They carry no
  answer, identity, command, session, or business authority.
- Machine credentials have only `machine-messages:write`,
  `machine-messages:read`, `machine-events:read`, and `machine-events:ack`,
  each constrained to the authenticated client's bound destination or stream.
  They cannot cancel messages or administer machine clients.
- Polling repeats unacknowledged events and accepts only the exact atomically
  committed cursor. Per-event acknowledgement advances only a contiguous
  prefix; safe quarantine cannot bypass identity, signature, or schema
  failures.
- `GET /v1/capabilities` returns a provider collection whose individual
  declarations validate against the standalone provider-capability schema.
- Customer applications and Agent Relay decide what an authenticated answer
  means. WhooshBang never serializes or issues an executable resume
  command.

## C0-04 boundaries

- `whooshbang.event.v1` is a strict nine-member customer-event union with
  stable public resource IDs and no bearer, callback token, raw provider
  identity, executable command, or original message body.
- Standard Webhooks V1 verification signs
  `<webhook-id>.<webhook-timestamp>.<raw-body>` with HMAC-SHA256, accepts at
  most current and previous `whsec_` keys during rotation, and enforces a
  five-minute-or-narrower replay window.
- Customer code checks the expected project and atomically deduplicates event
  IDs before business side effects, retaining successful claims for at least
  seven days.
- Delivery is at least once and unordered. Redirects are not followed; only
  network failures, 408, 425, 429, and 5xx are retryable, with at most eight
  attempts during 24 hours.
- The JavaScript verifier is Web Crypto-only. The packaged independent Python
  example uses only the standard library and passes the same deterministic
  byte vectors.

## Public package exports

- Package root: contract manifest, version, generated model types, named
  validators, machine-credential helpers, webhook verification/idempotent
  consumption, and delivery classification.
- `examples/python/verify_webhook.py`: independent standard-library verifier.
- `openapi/whooshbang-v1.yaml`: canonical OpenAPI 3.1.1 source.
- `openapi/whooshbang-v1.bundle.json`: deterministic self-contained bundle.
- `schemas/*`: canonical JSON Schema 2020-12 documents.
- `fixtures/*`: versioned synthetic golden fixtures and their machine-readable
  index.

## Stable root commands

```sh
npm run build
npm run check
npm run contracts:generate
npm run contracts:check
npm run contracts:pack
```

`contracts:check` validates the manifest and canonical documents, fixtures,
generated-file drift, package exports, package boundaries, and runtime
neutrality. `contracts:pack` repeats those checks, proves reproducible packing,
audits the tarball, and installs it into isolated npm and pnpm consumers. It
never publishes to a registry.
