# Changelog

All notable changes to the deterministic WhooshBang contract mock are
recorded here.

## 1.0.0-rc.5

- Reissue the deterministic mock against
  `@whooshbang/contracts@1.0.0-rc.5`, including the restored paused binding
  state and paused/revoked subscription fixtures.
- Keep `1.0.0-rc.4` immutable; no compatibility alias or migration is needed
  for the unpublished, undeployed candidate.

## 1.0.0-rc.4

- Rename the unused pre-launch package, CLI, public exports, control header,
  Problem Details origin, fixtures, and examples to the canonical WhooshBang
  identity with no compatibility aliases.

## 1.0.0-rc.3

- Add executable API credential create/list/rotate/revoke behavior for the
  approved N1-03 contract amendment, including one-time reveal, safe
  inspection, last-used updates, bounded overlap, and terminal revocation.
- Reissue the mock and its deterministic scenarios under a new immutable
  candidate identity; `1.0.0-rc.2` remains unchanged.

## 1.0.0-rc.2

- Add deterministic human-session fixtures and executable account/project
  administration routes for the N1-02 contract.
- Cover atomic test/live/default-notifier bootstrap, account-scoped
  idempotency, pagination, slug conflict, and non-enumerating cross-account
  reads under a new immutable candidate identity.

## 1.0.0-rc.1

- Promote the exact reviewed Wave 0/C0 mock from `1.0.0-draft.1` without a
  behavioral change.
- Retain the packaged C0SEC-002 cross-machine answer-origin regression and
  bounded npm/pnpm consumer proofs at the release-candidate version.
- Keep the mock repository-local, deterministic, and free of live provider,
  account, deployment, or production control dependencies.

## 1.0.0-draft.1

- Correct machine interaction-answer routing to enqueue an event only for the
  exact machine client recorded when the message was created.
- Fail safely without rerouting when that originating client is absent,
  revoked, or no longer matches the message binding.
- Add permanent cross-machine and unavailable-origin regression coverage for
  C0SEC-002. The canonical WhooshBang contract and JavaScript SDK are
  unchanged.
- Add the packaged `cross-machine-answer-origin` malicious scenario and execute
  its same-binding, absent-origin, revoked-origin, and mismatched-origin cases
  in both npm and pnpm tarball consumers.
