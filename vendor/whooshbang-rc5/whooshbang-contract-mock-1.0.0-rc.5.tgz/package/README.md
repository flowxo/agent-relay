# `@whooshbang/contract-mock`

Deterministic, in-memory WhooshBang V1 mock for local contract tests.
It implements the WhooshBang-owned release candidate without a cloud
account, network service, database, or production provider.

## Programmatic and Worker-compatible use

Each factory call owns isolated state:

```ts
import {
  CONTRACT_MOCK_FIXTURE_CREDENTIALS,
  createWhooshBangContractMock,
} from "@whooshbang/contract-mock";

const mock = createWhooshBangContractMock({ scenario: "nominal" });
const response = await mock.fetch(
  new Request("https://api.mock.whooshbang.test/v1/capabilities", {
    headers: {
      authorization:
        `Bearer ${CONTRACT_MOCK_FIXTURE_CREDENTIALS.projectTest}`,
    },
  }),
);
```

The mock also executes the account-scoped administration contract. Use
`humanSession` (or `otherHumanSession` for isolation tests) with
`GET /v1/account`, `GET/POST /v1/projects`, and
`GET /v1/projects/{project_id}`. Project creation atomically returns synthetic
`test` and `live` environments and one `Default` notifier for each.

The same human session can execute the environment credential lifecycle:
`GET/POST /v1/projects/{project_id}/environments/{environment_id}/credentials`
and the nested `rotate` and `revoke` actions. The mock emits a deterministic
synthetic `wb_pc1` bearer only from create/rotate, stores it outside the
inspection snapshot, models bounded overlap, updates safe last-used metadata
on authentication, and returns `credential_invalid` after revocation. These
values are local fixtures, not production credential material.

The fetch-only entry point is structurally compatible with a Worker module and
does not expose the test control API:

```ts
import {
  createWhooshBangContractMockWorker,
} from "@whooshbang/contract-mock/worker";

export default createWhooshBangContractMockWorker({
  scenario: "nominal",
});
```

This package deliberately includes no Wrangler configuration or deployment
workflow. The Worker-compatible entry is for runtime-neutral contract tests,
not a hosted or production WhooshBang service.

## Loopback CLI

After building or installing the package:

```sh
whooshbang-contract-mock --port 8787 --scenario nominal
```

Defaults are `--host 127.0.0.1`, `--port 0` (an ephemeral port),
`--scenario nominal`, and no HTTP control surface. Supported flags are
`--host`, `--port`, `--scenario`, and `--control-token`. Supplying a control
token restricts the listener to `127.0.0.1`, `::1`, or `localhost`; the token
must contain 8–4096 visible ASCII characters.

## Fixtures and scenarios

All credentials are synthetic local fixtures:

| Exported key | Bearer token | Identity |
| --- | --- | --- |
| `humanSession` | `human-session-token` | default account administrator |
| `otherHumanSession` | `human-other-session-token` | isolated account administrator |
| `projectTest` | `project-test-token` | default test project |
| `liveProject` | `project-live-token` | default live project |
| `projectA` | `project-a-token` | isolated test project A |
| `projectB` | `project-b-token` | isolated test project B |
| `readOnly` | `project-read-only-token` | read-only default project |
| `machineA` | `machine-a-token` | machine stream A |
| `machineB` | `machine-b-token` | machine stream B |

`CONTRACT_MOCK_SCENARIOS` is the typed scenario catalog. The same 25 names are
available in the exported JSON subpath
`@whooshbang/contract-mock/scenarios/v1/manifest.json`:

```text
nominal
repeated-idempotent-message
idempotency-conflict
unbound-subscriber
retryable-provider-failure
terminal-provider-rejection
ambiguous-provider-outcome
cancellation-before-send
cancellation-too-late
interaction-confirm
interaction-select
interaction-input
interaction-duplicate
interaction-stale
interaction-expired
interaction-unauthorized
machine-event-replay
machine-cursor-contiguous
machine-poison-quarantine
cross-machine-rejection
cross-machine-answer-origin
signed-webhook-success
signed-webhook-retry
signed-webhook-terminal
rate-limited
```

`cross-machine-answer-origin` is the executable C0SEC-002 fixture. Supply
synthetic same-binding machine credentials through the mock options, create an
interactive message as machine B, and submit its answer through
`mock.control.submitInteraction`. Only B may receive the resulting machine
event. If B's recorded client is absent, revoked, or no longer matches the
message binding, the interaction still resolves for the customer event while
the machine event fails closed instead of rerouting to machine A or another
same-binding peer.

## Explicit test control

The programmatic factory exposes `mock.control` directly. HTTP control routes
exist only in the loopback CLI when `--control-token` is supplied. Every request
must send that exact token in `WhooshBang-Contract-Mock-Token`.

| Route | Purpose |
| --- | --- |
| `GET /__contract-mock/snapshot` | inspect redacted deterministic state |
| `POST /__contract-mock/reset` | reset to a named scenario |
| `POST /__contract-mock/provider-outcomes` | replace provider outcomes |
| `POST /__contract-mock/webhook-responses` | replace receiver responses |
| `POST /__contract-mock/interactions` | submit a synthetic interaction |
| `POST /__contract-mock/run-pending` | run pending provider work |

Control routes are absent from OpenAPI and from the Worker-compatible entry.
Never expose the CLI control listener or fixture credentials as a production
service.
