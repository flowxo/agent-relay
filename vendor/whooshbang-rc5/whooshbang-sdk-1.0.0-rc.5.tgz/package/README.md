# `@whooshbang/sdk`

Fetch-injected, ESM-only client for the release-candidate WhooshBang V1
contract. The package has no automatic retry policy, persistence, telemetry,
Node-only runtime import, or Cloudflare binding.

```ts
import { WhooshBangClient } from "@whooshbang/sdk";

const whooshBang = new WhooshBangClient({
  baseUrl: "http://127.0.0.1:8787",
  credential: "synthetic-local-credential",
  fetch,
});

const message = await whooshBang.createMessage(
  {
    to: { subscriber_id: "customer_123" },
    content: { type: "text", text: "Your export is ready." },
  },
  {
    idempotencyKey: "export-job-987",
    signal: AbortSignal.timeout(5_000),
  },
);
```

Use a verified human-session token with the same client to call `getAccount`,
`listProjects`, `createProject`, `getProject`, `listApiCredentials`,
`createApiCredential`, `rotateApiCredential`, and `revokeApiCredential`.
Credential create and rotate calls intentionally have no response-replay key:
their complete bearer is a one-time response and cannot be retrieved later.
Treat a transport failure as outcome unknown, inspect safe metadata, and issue
then revoke a replacement. Product delivery methods continue to use project-
or machine-scoped credentials; the client does not persist either credential
kind.

Delivery, project creation, machine administration, and acknowledgement
side-effects require an explicit idempotency key. Credential lifecycle
create/rotate/revoke calls follow their one-time-reveal or intrinsic
repeat-safe contract instead. The client sends each call once. A transport
failure on a side effect raises `WhooshBangTransportError` with
`outcomeUnknown: true`; the caller decides whether a new logical operation is
appropriate.

The exact runtime dependency is
`@whooshbang/contracts@1.0.0-rc.5`. Successful payloads are
validated with its packaged validators, while additive response fields remain
available on the returned object. Standard Webhooks verification is exported
as both `verifyWebhookSignature` and `verifyWhooshBangWebhook`.
