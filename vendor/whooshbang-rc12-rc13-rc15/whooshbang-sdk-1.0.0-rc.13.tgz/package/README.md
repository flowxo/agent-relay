# `@whooshbang/sdk`

Fetch-injected, ESM-only client for the release-candidate WhooshBang V1
contract. The package has no automatic retry policy, persistence, telemetry,
Node-only runtime import, or Cloudflare binding.

```ts
import { WhooshBangClient, confirmInteraction } from "@whooshbang/sdk";

const whooshBang = new WhooshBangClient({
  baseUrl: "http://127.0.0.1:8787",
  credential: "synthetic-local-credential",
  fetch,
});

const message = await whooshBang.createMessage(
  {
    to: { subscriber_id: "customer_123" },
    content: { type: "text", text: "A deployment is waiting." },
    interaction: confirmInteraction({
      prompt: "Approve the synthetic deployment?",
      confirmLabel: "Approve",
      denyLabel: "Deny",
      expiresInSeconds: 900,
    }),
  },
  { idempotencyKey: "deploy-approval-987", timeoutMs: 10_000 },
);
```

## Interaction builders

`confirmInteraction`, `selectInteraction`, and `inputInteraction` produce
exactly the C0 tagged interaction union and enforce every documented bound —
prompt and label lengths, two to six unique select options, correlation-id
shape — before any request is built. A violation raises
`WhooshBangValidationError` listing the offending field paths and rule names.
The offending values are deliberately absent: builder input carries prompts and
option labels, which never belong in an error, a log, or a stack trace.

Supply `expiresInSeconds` (30 through 86400) to compute the expiry locally, or
`expiresAt` to set it exactly. The 30-second-to-24-hour window is measured from
server acceptance, so only the value this package computes is bounded here.

## Bounded response inspection

`getMessage` and `getInteraction` accept `wait`, the server-held long poll in
whole seconds from 0 through 30. Omitting it uses the documented server default
of 30. A wait that expires is a successful current-state read, not an error, so
a listener-less consumer simply reads again. Inspection never acknowledges,
consumes, retries, or replays anything.

`interactionAnswer` reads a terminal summary as the same tagged union the
machine stream and signed customer events carry, and returns nothing once the
typed answer has left its retention window — `answered` and `answered_at`
survive that deletion, the answer does not.

## Endpoint lifecycle and webhook verification

`createCustomerEndpoint`, `verifyCustomerEndpoint`, `rotateCustomerEndpoint`,
`pauseCustomerEndpoint`, `resumeCustomerEndpoint`, `disableCustomerEndpoint`,
`listCustomerEndpoints`, `getCustomerEndpoint`, and
`listCustomerEndpointAttempts` cover the endpoint lifecycle. The signing secret
is revealed exactly once, by create and by rotate; an equivalent idempotent
replay returns the same logical endpoint without it.

`verifyWhooshBangEvent` verifies the Standard Webhooks envelope over the exact
raw request bytes and returns the typed customer event. Read the body as bytes:
framework JSON re-serialization changes the signed input. Verification enforces
the replay window, fails closed on an unknown signature version, and accepts
both the previous and the current secret so a rotation overlap has no gap. Use
`verifyWhooshBangWebhook` (or `verifyWebhookSignature`) for signature-only
verification of any signed body.

## Machine clients

`createMachineCredential` generates the C0-03 secret with Web Crypto and
returns the readable bearer plus a digest-only `registration`. Only the
registration may be sent; the service never receives, stores, or can return the
secret. `registerMachineCredential`, `revokeMachineCredential`,
`revokeMachineClient`, `pollMachineEvents`, and `acknowledgeMachineEvent`
complete the stream lifecycle. Rotate by registering the replacement first and
revoking the original second.

The machine stream is proved against the deterministic C0-05 contract mock.
The production machine-stream service is a separate story.

## Errors

| Class | Meaning |
| --- | --- |
| `WhooshBangValidationError` | Caller input broke a documented bound. No request was made. Extends `TypeError`. |
| `WhooshBangContractError` | A request or response did not match the pinned contract. |
| `WhooshBangProblemError` | The API returned Problem Details, with `code`, `status`, `diagnosticId`, `retryable`, and `retryAt` preserved. |
| `WhooshBangProtocolError` | The response was not a usable WhooshBang response. |
| `WhooshBangTransportError` | The request could not be completed. |
| `WhooshBangAbortError` | The caller's `AbortSignal` fired. |
| `WhooshBangTimeoutError` | The caller's `timeoutMs` elapsed. |

The last three carry `outcomeUnknown`: a cancelled or failed side effect may
already have been applied, and the client never resolves that on your behalf.

Use a verified human-session token with the same client to call `getAccount`,
`listProjects`, `createProject`, `getProject`, `listApiCredentials`,
`createApiCredential`, `rotateApiCredential`, and `revokeApiCredential`.
Credential create and rotate calls intentionally have no response-replay key:
their complete bearer is a one-time response and cannot be retrieved later.
Treat a transport failure as outcome unknown, inspect safe metadata, and issue
then revoke a replacement. Product delivery methods continue to use project-
or machine-scoped credentials; the client does not persist either credential
kind.

Delivery, project creation, endpoint create/rotate, machine administration, and
acknowledgement side-effects require an explicit idempotency key. Credential
lifecycle create/rotate/revoke calls follow their one-time-reveal or intrinsic
repeat-safe contract instead. The client sends each call exactly once. A
transport failure on a side effect raises an error with
`outcomeUnknown: true`; the caller decides whether a new logical operation is
appropriate. With a caller key, an explicit retry returns the original result
and creates no duplicate.

## Cancellation and deadlines

Every method accepts `signal` and `timeoutMs` (1 through 300000 milliseconds).
When only one is supplied it reaches `fetch` unchanged. Neither adds a retry:
they bound waiting, and neither claims a server outcome after cancellation.

## Optional logging

`logger` receives one record per attempted request containing the operation name,
outcome, duration, HTTP status, public diagnostic identifier, problem code,
retryability, and retry time. Credentials, URLs, request bodies, prompts,
answers, and signing material are structurally absent rather than redacted. A
hook that throws never changes the operation's outcome. Caller input is checked
before the attempt begins, so a local refusal throws at your call site rather
than arriving as a log record.

## Examples

Runnable scripts for the interactive send, bounded polling, raw-body webhook
verification, endpoint lifecycle, and machine bootstrap flows live in the
repository under `packages/sdk-js/examples/`. They are deliberately not part of
the published tarball, which carries only `dist` and this README. From a
repository checkout they run against any base URL and default to the local
deterministic mock:

```sh
npx whooshbang-contract-mock --port 8787 --scenario machine-event-replay
node packages/sdk-js/examples/send-interactive-message.mjs
```

## Compatibility

The exact runtime dependency is
`@whooshbang/contracts@1.0.0-rc.12`. Successful payloads are
validated with its packaged validators, while additive response fields remain
available on the returned object.
