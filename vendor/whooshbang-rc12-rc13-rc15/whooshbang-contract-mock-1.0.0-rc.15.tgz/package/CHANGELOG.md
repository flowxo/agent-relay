# Changelog

All notable changes to the deterministic WhooshBang contract mock are
recorded here.

## 1.0.0-rc.15

- Exclude already-acknowledged events from machine polls, including
  acknowledgements recorded beyond an earlier cursor gap.
- Report a repeated successful acknowledgement as `existing` with the current
  committed cursor instead of replaying the first response body.
- Reissue against contracts `1.0.0-rc.12`, SDK `1.0.0-rc.13`, and MCP
  `1.0.0-rc.4`; the published schemas and fixture semantics are unchanged and
  `1.0.0-rc.14` remains immutable.

## 1.0.0-rc.14

- Reissue the mock against `@whooshbang/contracts@1.0.0-rc.11` and
  `@whooshbang/sdk@1.0.0-rc.12` for the combined replay-refusal and
  machine-answer-retention contract.
- Publish `answer_retained: true` on every retained `interaction.received`
  event the mock creates or seeds; consumers may also validate the contract's
  redacted false-without-response shape.
- Include the new closed `replay_unavailable` Problem code through the public
  contract vocabulary. `1.0.0-rc.13` remains immutable.

## 1.0.0-rc.12

- Exercise the WhooshBang MCP tools against the mock over both the stdio and
  the OAuth-secured remote transport, so the coding-agent surface is proven
  against the published contract rather than against a stub.
- Runtime behaviour, scenarios, fixtures, and the published contract are
  unchanged; only the package's development dependencies and its test suite
  moved.
- Keep `@whooshbang/contracts@1.0.0-rc.9` immutable.

## 1.0.0-rc.11

- Add the deterministic customer-endpoint lifecycle: create with a one-time
  secret reveal, verify, bounded-overlap rotation with a rotation conflict,
  pause, resume, disable, attempt inspection, and cross-environment refusal.
- Authenticate a locally generated C0-03 machine bearer against its registered
  digest, so digest-only bootstrap, rotation, and revocation are provable end
  to end without the service ever seeing the secret.
- Default the loopback CLI to the system clock so a caller can send an
  interaction whose expiry is computed from real time; `--clock fixed` restores
  the frozen clock, and the programmatic factory stays frozen.
- Keep `@whooshbang/contracts@1.0.0-rc.9` immutable.

## 1.0.0-rc.10

- Add deterministic per-message and per-interaction response inspection,
  including bounded wait, wake, timeout, and machine-ownership behavior for
  `@whooshbang/contracts@1.0.0-rc.9`.
- Keep polling side-effect free and `1.0.0-rc.9` immutable.

## 1.0.0-rc.9

- Reissue the deterministic mock and SDK compatibility boundary against
  `@whooshbang/contracts@1.0.0-rc.8` without adding endpoint behavior.
- Keep `1.0.0-rc.8` immutable.

## 1.0.0-rc.8

- Reissue the deterministic mock against `@whooshbang/contracts@1.0.0-rc.7`
  with explicit retained/redacted answered-interaction summaries.
- Keep `1.0.0-rc.7` immutable.

## 1.0.0-rc.7

- Reissue the deterministic mock with Hono 4.12.34 to address
  `GHSA-8j4g-w8fx-2239`; contract behavior and fixtures are unchanged.
- Keep `1.0.0-rc.6` immutable.

## 1.0.0-rc.6

- Reissue the deterministic mock and SDK against
  `@whooshbang/contracts@1.0.0-rc.6` after moving the generated production API
  server origin to `https://api.whooshbang.com`.
- Keep `1.0.0-rc.5` immutable; runtime behavior and pinned V1 Problem Details
  and schema identifiers are unchanged.

## 1.0.0-rc.5

- Reissue the deterministic mock against
  `@whooshbang/contracts@1.0.0-rc.5`, including the restored paused binding
  state and paused/revoked subscription fixtures.
- Keep `1.0.0-rc.4` immutable; no compatibility alias or migration is needed
  for the unpublished, undeployed candidate.

## 1.0.0-rc.4

- Rename the unused pre-launch package, CLI, public exports, control header,
  Problem Details origin, fixtures, and examples to the canonical WhooshBang
  identity with no compatibility aliases.

## 1.0.0-rc.3

- Add executable API credential create/list/rotate/revoke behavior for the
  approved N1-03 contract amendment, including one-time reveal, safe
  inspection, last-used updates, bounded overlap, and terminal revocation.
- Reissue the mock and its deterministic scenarios under a new immutable
  candidate identity; `1.0.0-rc.2` remains unchanged.

## 1.0.0-rc.2

- Add deterministic human-session fixtures and executable account/project
  administration routes for the N1-02 contract.
- Cover atomic test/live/default-notifier bootstrap, account-scoped
  idempotency, pagination, slug conflict, and non-enumerating cross-account
  reads under a new immutable candidate identity.

## 1.0.0-rc.1

- Promote the exact reviewed Wave 0/C0 mock from `1.0.0-draft.1` without a
  behavioral change.
- Retain the packaged C0SEC-002 cross-machine answer-origin regression and
  bounded npm/pnpm consumer proofs at the release-candidate version.
- Keep the mock repository-local, deterministic, and free of live provider,
  account, deployment, or production control dependencies.

## 1.0.0-draft.1

- Correct machine interaction-answer routing to enqueue an event only for the
  exact machine client recorded when the message was created.
- Fail safely without rerouting when that originating client is absent,
  revoked, or no longer matches the message binding.
- Add permanent cross-machine and unavailable-origin regression coverage for
  C0SEC-002. The canonical WhooshBang contract and JavaScript SDK are
  unchanged.
- Add the packaged `cross-machine-answer-origin` malicious scenario and execute
  its same-binding, absent-origin, revoked-origin, and mismatched-origin cases
  in both npm and pnpm tarball consumers.
