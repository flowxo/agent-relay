# Changelog

All notable contract changes are recorded here.

## 1.0.0-rc.12

- Reissue the unchanged schema and fixture semantics as the coordinated
  contract identity for SDK `1.0.0-rc.13` and deterministic mock
  `1.0.0-rc.15`.
- The mock now omits already-acknowledged events from polls and re-derives a
  repeated acknowledgement from durable state, matching the existing C0-03
  fixtures and semantics model. `1.0.0-rc.11` remains immutable.

## 1.0.0-rc.11

- Add the closed `replay_unavailable` Problem code at HTTP 409. Replay
  refusals retain the `not_terminal`, `payload_unavailable`, or
  `rollout_disabled` field error that tells an integrator which state blocked
  the operation.
- Allow `interaction.received` machine events to outlive answer content. New
  retained events publish `answer_retained: true` with `response`; redacted
  events publish `answer_retained: false` and omit `response`.
- Accept a retained legacy event with `response` and no retention marker during
  a rolling deployment. Absence is never a redaction signal; only the published
  `answer_retained: false` shape is.
- Breaking: exhaustive `ProblemCode` consumers must handle the new member, and
  machine-event consumers must tolerate a redacted event without `response`.
  `1.0.0-rc.10` remains immutable.

## 1.0.0-rc.10

- Add the environment-scoped form of each operation an account-scoped caller
  needs — subscription-link create and read, message create and read,
  interaction read, machine-client create, and capabilities — alongside the
  flat forms, which are untouched and remain credential-only.
- Add a `bearerGrant` security scheme, and attach it to those operations, to
  the account and project operations, and to the customer-endpoint operations
  that already carry project and environment in their paths.
- Split the scope vocabulary by level. Project-level scopes are the credential
  vocabulary unchanged and stay mirrored exactly; the account-level scopes
  `projects:read` and `projects:write` exist only on a grant or a human
  session, because a credential lives inside a project and can never create or
  enumerate its siblings.
- Additive throughout: every existing request and response is unchanged.

## 1.0.0-rc.9

- Add authenticated per-message and per-interaction canonical response
  inspection with a bounded zero-to-30-second wait that defaults to 30.
- Preserve first-terminal-writer and retained/redacted answer semantics while
  making wait expiry a successful current-state response.
- Reissue the unpublished contract as a new immutable candidate;
  `1.0.0-rc.8` remains unchanged.

## 1.0.0-rc.8

- Add project/environment customer-endpoint create, signed verification,
  secret rotation, lifecycle, health, and safe attempt-diagnostic operations.
- Add one-time secret result, verification challenge, endpoint resource, and
  diagnostic fixtures while preserving the existing Standard Webhooks and
  idempotency semantics.
- Preserve each promised rotation overlap by returning a typed conflict when
  another rotation is requested before the prior overlap expires.
- Reissue the unpublished contract as a new immutable candidate;
  `1.0.0-rc.7` remains unchanged.

## 1.0.0-rc.7

- Preserve the first-terminal-writer `answered` state after normalized answer
  deletion with explicit `answer_retained` status semantics: retained answers
  remain typed; redacted summaries keep `answered_at` and omit `answer`.
- Add retained and redacted golden interaction summaries and regenerate the
  public types, validators, OpenAPI bundle, SDK, and deterministic mock.
- Reissue the unpublished contract as a new immutable candidate;
  `1.0.0-rc.6` remains unchanged.

## 1.0.0-rc.6

- Generate the deployed production API server origin from the canonical
  Cloudflare resource manifest and move it to `https://api.whooshbang.com`.
- Keep the existing V1 Problem Details and JSON Schema URI identifiers pinned
  to their immutable `whooshbang.flowxo.com` identities.
- Reissue the contract, SDK, mock, generated output, and fixture identities as
  a new immutable candidate; `1.0.0-rc.5` remains unchanged.
- No compatibility shim or runtime migration is required because the prior
  candidate was unpublished and the product has not been deployed.

## 1.0.0-rc.5

- Restore the documented `paused` Telegram binding state to the C0
  `BindingSummary` candidate alongside `active` and `revoked`.
- Add schema-valid paused and revoked subscription-link fixtures so consumers
  prove all subscriber-control states instead of inferring them.
- Reissue the contract, SDK, mock, generated output, and fixture identities as
  a new immutable candidate; `1.0.0-rc.4` remains unchanged.
- No compatibility shim or runtime migration is required because the prior
  candidate was unpublished and the product has not been deployed.

## 1.0.0-rc.4

- Replace the unused pre-launch product identity with WhooshBang across the
  package name, OpenAPI and schema identities, Problem Details origin,
  diagnostic header, event envelope, project and machine credential markers,
  generated types, validators, fixtures, and consumer examples.
- Rename the public package to `@whooshbang/contracts`; the prior candidate
  was never published and has no compatibility or migration requirement.

## 1.0.0-rc.3

- Add the approved N1-03 API credential lifecycle contract: account-owned
  project/environment administration paths, exact high-entropy bearer syntax,
  one-time create/rotate reveal, metadata-only listing, a zero-to-24-hour
  rotation overlap, terminal repeat-safe revocation, and indistinguishable
  invalid/revoked authentication.
- Keep published credential examples unmistakably synthetic with low-entropy
  sentinel values so repository secret scanning remains actionable.
- Require a distinct newly active replacement, coherent lifecycle timestamps,
  and an explicit old-credential revocation deadline in rotation responses;
  extend deployable-artifact scanning to WhooshBang bearer formats.
- Reissue the contract, SDK, mock, fixtures, and generated artifacts under a
  new immutable candidate identity; `1.0.0-rc.2` remains unchanged.

## 1.0.0-rc.2

- Add the N1-02 human-administration contract to the reviewed release-candidate
  line: current account projection, project create/list/read, atomic
  `test`/`live` environment and default-notifier bootstrap, account-scoped
  idempotency, slug conflict, and non-enumerating cross-account behavior.
- Reissue the manifest, schemas, fixtures, OpenAPI bundle, generated types, and
  validators under a new immutable candidate identity; `1.0.0-rc.1` remains
  unchanged.

## 1.0.0-rc.1

- Promote the exact reviewed Wave 0/C0 contract from `1.0.0-draft.1` without a
  public semantic change.
- Reissue every manifest, schema, fixture identity, OpenAPI document, generated
  output, and package-consumer assertion at the release-candidate version after
  the compatibility and adversarial security gates passed.
- Keep the candidate repository-local and unpublished so downstream consumers
  can pin and verify the exact artifact before any independent product release.

## 1.0.0-draft.1

- Establish the versioned contract workspace, ownership manifest, and package
  boundary.
- Add the canonical WhooshBang OpenAPI 3.1.1 contract for subscription-link
  creation, inspection, and cancellation and message creation, inspection, and
  cancellation.
- Add strict JSON Schema 2020-12 request, resource, delivery-attempt, binding,
  Problem Details, fixture-index, and semantic-scenario models.
- Add deterministic generated TypeScript, runtime validators, a bundled OpenAPI
  document, and golden fixtures covering success, failure, idempotency, state,
  cancellation, and tenant/environment isolation.
- Record seven-day idempotency, authenticated scope, safe error, and
  ambiguous-provider `outcome_unknown` semantics without adding production
  service, SDK, interaction, webhook, or executable mock behavior.
- Add the C0-03 tagged confirm, single-select, and input interaction request,
  lifecycle summary, and authenticated answer-event contracts with bounded
  prompts/options/input, opaque callback tokens, strict expiry ordering, and
  deterministic duplicate/stale/expired/mismatched fixtures.
- Add project-administered machine-client and digest-only credential
  registration/revocation contracts, exact locally generated
  `wb_mc1.<credential-id>.<secret>` syntax, Web Crypto generation and
  constant-time digest verification helpers, and safe metadata responses that
  contain neither a readable secret nor digest.
- Add bounded long polling, at-least-seven-day event retention, per-event
  idempotent acknowledgement, contiguous committed cursors, crash replay,
  fail-closed foreign/uncommitted cursors, and schema-valid poison-event
  quarantine.
- Add provider-neutral capability declarations and an additive unique-provider
  collection with Telegram acceptance evidence and explicit lack of
  delivered/read evidence.
- Add the strict `whooshbang.event.v1` envelope, nine initial per-event
  schemas, generated types/validators, and safe synthetic event fixtures.
- Add Standard Webhooks-compatible raw-byte HMAC-SHA256 verification using
  Worker- and Node-compatible Web Crypto, bounded current/previous key
  rotation, strict replay/header parsing, and 28 deterministic valid and
  adversarial vectors.
- Add an independently implemented Python standard-library verifier over the
  same byte vectors and include it in the immutable package boundary.
- Add a caller-owned atomic deduplication consumer example with expected
  project/event checks and seven-day retention, plus deterministic at-least-
  once delivery classification for 2xx, redirects, retryable outcomes, safe
  Retry-After, eight attempts, and a 24-hour window.
- Keep machine message create/read authorization narrowly bound to the
  authenticated client destination and owned message IDs; cancellation,
  administration, Relay continuation/resume, multi-select/ordered sets,
  endpoint registration/delivery queues, WebSockets, SDK networking, and
  executable mock behavior remain outside this change.
