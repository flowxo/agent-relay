# Changelog

All notable changes to the deterministic Notifications contract mock are
recorded here.

## 1.0.0-rc.1

- Promote the exact reviewed Wave 0/C0 mock from `1.0.0-draft.1` without a
  behavioral change.
- Retain the packaged C0SEC-002 cross-machine answer-origin regression and
  bounded npm/pnpm consumer proofs at the release-candidate version.
- Keep the mock repository-local, deterministic, and free of live provider,
  account, deployment, or production control dependencies.

## 1.0.0-draft.1

- Correct machine interaction-answer routing to enqueue an event only for the
  exact machine client recorded when the message was created.
- Fail safely without rerouting when that originating client is absent,
  revoked, or no longer matches the message binding.
- Add permanent cross-machine and unavailable-origin regression coverage for
  C0SEC-002. The canonical Notifications contract and JavaScript SDK are
  unchanged.
- Add the packaged `cross-machine-answer-origin` malicious scenario and execute
  its same-binding, absent-origin, revoked-origin, and mismatched-origin cases
  in both npm and pnpm tarball consumers.
