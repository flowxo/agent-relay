# `@flowxo/notifications`

Fetch-injected, ESM-only client for the release-candidate FlowXO Notifications V1
contract. The package has no automatic retry policy, persistence, telemetry,
Node-only runtime import, or Cloudflare binding.

```ts
import { NotificationsClient } from "@flowxo/notifications";

const notifications = new NotificationsClient({
  baseUrl: "http://127.0.0.1:8787",
  credential: "synthetic-local-credential",
  fetch,
});

const message = await notifications.createMessage(
  {
    to: { subscriber_id: "customer_123" },
    content: { type: "text", text: "Your export is ready." },
  },
  {
    idempotencyKey: "export-job-987",
    signal: AbortSignal.timeout(5_000),
  },
);
```

Side-effecting methods require an explicit idempotency key. The client sends
each call once. A transport failure on a side effect raises
`NotificationsTransportError` with `outcomeUnknown: true`; the caller decides
whether a new logical operation is appropriate.

The exact runtime dependency is
`@flowxo/notifications-contracts@1.0.0-rc.1`. Successful payloads are
validated with its packaged validators, while additive response fields remain
available on the returned object. Standard Webhooks verification is exported
as both `verifyWebhookSignature` and `verifyNotificationsWebhook`.
