# Changelog

All notable contract changes are recorded here.

## 1.0.0-draft.1

- Establish the versioned contract workspace, ownership manifest, and package
  boundary.
- Add the canonical Notifications OpenAPI 3.1.1 contract for subscription-link
  creation, inspection, and cancellation and message creation, inspection, and
  cancellation.
- Add strict JSON Schema 2020-12 request, resource, delivery-attempt, binding,
  Problem Details, fixture-index, and semantic-scenario models.
- Add deterministic generated TypeScript, runtime validators, a bundled OpenAPI
  document, and golden fixtures covering success, failure, idempotency, state,
  cancellation, and tenant/environment isolation.
- Record seven-day idempotency, authenticated scope, safe error, and
  ambiguous-provider `outcome_unknown` semantics without adding production
  service, SDK, interaction, webhook, or executable mock behavior.
- Add the C0-03 tagged confirm, single-select, and input interaction request,
  lifecycle summary, and authenticated answer-event contracts with bounded
  prompts/options/input, opaque callback tokens, strict expiry ordering, and
  deterministic duplicate/stale/expired/mismatched fixtures.
- Add project-administered machine-client and digest-only credential
  registration/revocation contracts, exact locally generated
  `fxon_mc1.<credential-id>.<secret>` syntax, Web Crypto generation and
  constant-time digest verification helpers, and safe metadata responses that
  contain neither a readable secret nor digest.
- Add bounded long polling, at-least-seven-day event retention, per-event
  idempotent acknowledgement, contiguous committed cursors, crash replay,
  fail-closed foreign/uncommitted cursors, and schema-valid poison-event
  quarantine.
- Add provider-neutral capability declarations and an additive unique-provider
  collection with Telegram acceptance evidence and explicit lack of
  delivered/read evidence.
- Add the strict `notifications.event.v1` envelope, nine initial per-event
  schemas, generated types/validators, and safe synthetic event fixtures.
- Add Standard Webhooks-compatible raw-byte HMAC-SHA256 verification using
  Worker- and Node-compatible Web Crypto, bounded current/previous key
  rotation, strict replay/header parsing, and 28 deterministic valid and
  adversarial vectors.
- Add an independently implemented Python standard-library verifier over the
  same byte vectors and include it in the immutable package boundary.
- Add a caller-owned atomic deduplication consumer example with expected
  project/event checks and seven-day retention, plus deterministic at-least-
  once delivery classification for 2xx, redirects, retryable outcomes, safe
  Retry-After, eight attempts, and a 24-hour window.
- Keep machine message create/read authorization narrowly bound to the
  authenticated client destination and owned message IDs; cancellation,
  administration, Relay continuation/resume, multi-select/ordered sets,
  endpoint registration/delivery queues, WebSockets, SDK networking, and
  executable mock behavior remain outside this change.
