# `@flowxo/notifications-contract-mock`

Deterministic, in-memory FlowXO Notifications V1 mock for local contract tests.
It implements the Notifications-owned draft contract without a cloud account,
network service, database, or production provider.

## Programmatic and Worker-compatible use

Each factory call owns isolated state:

```ts
import {
  CONTRACT_MOCK_FIXTURE_CREDENTIALS,
  createNotificationsContractMock,
} from "@flowxo/notifications-contract-mock";

const mock = createNotificationsContractMock({ scenario: "nominal" });
const response = await mock.fetch(
  new Request("https://notifications.mock.test/v1/capabilities", {
    headers: {
      authorization:
        `Bearer ${CONTRACT_MOCK_FIXTURE_CREDENTIALS.projectTest}`,
    },
  }),
);
```

The fetch-only entry point is structurally compatible with a Worker module and
does not expose the test control API:

```ts
import {
  createNotificationsContractMockWorker,
} from "@flowxo/notifications-contract-mock/worker";

export default createNotificationsContractMockWorker({
  scenario: "nominal",
});
```

This package deliberately includes no Wrangler configuration or deployment
workflow. The Worker-compatible entry is for runtime-neutral contract tests,
not a hosted or production Notifications service.

## Loopback CLI

After building or installing the package:

```sh
flowxo-notifications-contract-mock --port 8787 --scenario nominal
```

Defaults are `--host 127.0.0.1`, `--port 0` (an ephemeral port),
`--scenario nominal`, and no HTTP control surface. Supported flags are
`--host`, `--port`, `--scenario`, and `--control-token`. Supplying a control
token restricts the listener to `127.0.0.1`, `::1`, or `localhost`; the token
must contain 8–4096 visible ASCII characters.

## Fixtures and scenarios

All credentials are synthetic local fixtures:

| Exported key | Bearer token | Identity |
| --- | --- | --- |
| `projectTest` | `project-test-token` | default test project |
| `liveProject` | `project-live-token` | default live project |
| `projectA` | `project-a-token` | isolated test project A |
| `projectB` | `project-b-token` | isolated test project B |
| `readOnly` | `project-read-only-token` | read-only default project |
| `machineA` | `machine-a-token` | machine stream A |
| `machineB` | `machine-b-token` | machine stream B |

`CONTRACT_MOCK_SCENARIOS` is the typed scenario catalog. The same 24 names are
available in the exported JSON subpath
`@flowxo/notifications-contract-mock/scenarios/v1/manifest.json`:

```text
nominal
repeated-idempotent-message
idempotency-conflict
unbound-subscriber
retryable-provider-failure
terminal-provider-rejection
ambiguous-provider-outcome
cancellation-before-send
cancellation-too-late
interaction-confirm
interaction-select
interaction-input
interaction-duplicate
interaction-stale
interaction-expired
interaction-unauthorized
machine-event-replay
machine-cursor-contiguous
machine-poison-quarantine
cross-machine-rejection
signed-webhook-success
signed-webhook-retry
signed-webhook-terminal
rate-limited
```

## Explicit test control

The programmatic factory exposes `mock.control` directly. HTTP control routes
exist only in the loopback CLI when `--control-token` is supplied. Every request
must send that exact token in `X-Contract-Mock-Token`.

| Route | Purpose |
| --- | --- |
| `GET /__contract-mock/snapshot` | inspect redacted deterministic state |
| `POST /__contract-mock/reset` | reset to a named scenario |
| `POST /__contract-mock/provider-outcomes` | replace provider outcomes |
| `POST /__contract-mock/webhook-responses` | replace receiver responses |
| `POST /__contract-mock/interactions` | submit a synthetic interaction |
| `POST /__contract-mock/run-pending` | run pending provider work |

Control routes are absent from OpenAPI and from the Worker-compatible entry.
Never expose the CLI control listener or fixture credentials as a production
service.
